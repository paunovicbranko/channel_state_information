pkg load signal
pkg load communications
csi_trace = read_bf_file('sample_data/1804.dat');
for i = 1:length(csi_trace)
	csi_entry = csi_trace{i};
	csi = get_scaled_csi(csi_entry);
	csi = csi(1, :, :);
	csi = squeeze(csi);
	SNR = db(abs(csi).');
	phi = [];
	for j = 1:3
	phi = [phi; sanitize_phase(angle(csi(j, :)))];
	end
	phi = phi';
	subplot(2, 1, 1)
	plot(SNR)
	%legend('Rx. Ant. A', 'Rx Ant. B', 'Rx Ant. C', 'Location', 'SouthEast' );
	%xlabel('Subcarrier index');
	ylabel('SNR [dB]');
	axis ([1 30 -10 30])
	subplot(2, 1, 2)
	plot(phi)
	%legend('Rx. Ant. A', 'Rx Ant. B', 'Rx Ant. C', 'Location', 'SouthOutside' );
	xlabel('Subcarrier index');
	ylabel('Phase [rad]');
	axis ([1 30 -10 10])

	filestem = sprintf('CSI_%04d', i);
	print(filestem, '-dpng');
	clf
end



pkg load signal
pkg load communications
csi_trace = read_bf_file('sample_data/1804.dat');

A10 = [];
phi10 = [];
A17 = [];
phi17 = [];
A23 = [];
phi23 = [];

for i = 1:length(csi_trace)
	csi_entry = csi_trace{i};
	csi = get_scaled_csi(csi_entry);
	csi = csi(1, :, :);
	csi = squeeze(csi);
	SNR = db(abs(csi).');
	phi = [];
	for j = 1:3
	phi = [phi; sanitize_phase(angle(csi(j, :)))];
	end
	phi = phi';

	A10 = [A10; SNR(10, :)];
	phi10 = [phi10; phi(10, :)];
	A17 = [A17; SNR(17, :)];
	phi17 = [phi17; phi(17, :)];
	A23 = [A23; SNR(23, :)];
	phi23 = [phi23; phi(23, :)];

end

subplot(2, 1, 1)
plot(A10)
axis tight
title('Subcarrier #10')
ylabel('SNR [dB]');
subplot(2, 1, 2)
plot(phi10)
axis tight
xlabel('Packet No.');
ylabel('Phase [rad]');
figure
subplot(2, 1, 1)
plot(A17)
axis tight
title('Subcarrier #17')
ylabel('SNR [dB]');
subplot(2, 1, 2)
plot(phi17)
axis tight
xlabel('Packet No.');
ylabel('Phase [rad]');
figure
subplot(2, 1, 1)
plot(A23)
axis tight
title('Subcarrier #23')
ylabel('SNR [dB]');
subplot(2, 1, 2)
plot(phi23)
axis tight
xlabel('Packet No.');
ylabel('Phase [rad]');


	filestem = sprintf('CSI_%04d', i);
	print(filestem, '-dpng');
	clf

