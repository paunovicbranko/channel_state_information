pkg load signal;
file = input("Unesite ime fajla \n", 's');
csi_trace = read_bf_file(file);
snr5= [];
snr10= [];
snr15= [];
snr20= [];
snr25= [];
faza1 = [];
faza2 = [];
faza3 = [];
faza5 = [];
faza10 = [];
faza15= [];
faza20 = [];
faza25 = [];

for i=1:length(csi_trace)
	csi_entry = csi_trace{i};
	csi = get_scaled_csi(csi_entry);
	csi = csi(1, :, :);
	snr = db(abs(squeeze(csi).'));
	csi_ = squeeze(csi);
	faza1 = [faza1; sanitize_phase(angle(csi_(1,:)))];
	faza2 = [faza2; sanitize_phase(angle(csi_(2,:)))];
	faza3 = [faza3; sanitize_phase(angle(csi_(3,:)))];
	snr5= [snr5; snr(5, :)];
	snr10= [snr10; snr(10, :)];
	snr15= [snr15; snr(15, :)];
	snr20= [snr20; snr(20, :)];
	snr25= [snr25; snr(25, :)];
end;

faza5 = [faza1(:, 5), faza2(:,5), faza3(:,5)];
faza10 = [faza1(:, 10), faza2(:,10), faza3(:,10)];
faza15 = [faza1(:, 15), faza2(:,15), faza3(:,15)];
faza20 = [faza1(:, 20), faza2(:,20), faza3(:,20)];
faza25 = [faza1(:, 25), faza2(:,25), faza3(:,25)];

snr5 = medfilt1(snr5, 4);
snr10 = medfilt1(snr10, 4);
snr15 = medfilt1(snr15, 4);
snr20 = medfilt1(snr20, 4);
snr25 = medfilt1(snr25, 4);
faza5 = medfilt1(faza5, 4);
faza10 = medfilt1(faza10,4);
faza15 = medfilt1(faza15,4);
faza20 = medfilt1(faza20,4);
faza25 = medfilt1(faza25,4);

figure(1),
subplot(2,1,1),
plot(snr5),
axis tight,
grid on,
ylabel("SNR [dB]"),
title("Subcarrier #5"),
subplot(2,1,2),
plot(faza5),
axis tight,
grid on,
ylabel("Phase [rad]");

figure(2),
subplot(2,1,1),
plot(snr10),
axis tight,
grid on,
ylabel("SNR [dB]"),
title("Subcarrier #10"),
subplot(2,1,2),
plot(faza10),
axis tight,
grid on,
ylabel("Phase [rad]");

figure(3),
subplot(2,1,1),
plot(snr15),
axis tight,
grid on,
ylabel("SNR [dB]"),
title("Subcarrier #15"),
subplot(2,1,2),
plot(faza15),
axis tight,
grid on,
ylabel("Phase [rad]");

figure(4),
subplot(2,1,1),
plot(snr20),
axis tight,
grid on,
ylabel("SNR [dB]"),
title("Subcarrier #20"),
subplot(2,1,2),
plot(faza20),
axis tight,
grid on,
ylabel("Phase [rad]");

figure(5),
subplot(2,1,1),
plot(snr25),
axis tight,
grid on,
ylabel("SNR [dB]"),
title("Subcarrier #25"),
subplot(2,1,2),
plot(faza25),
axis tight,
grid on,
ylabel("Phase [rad]");
